package com.senac.executaveis;

import com.senac.classes.Pessoa;

public class Executavel {

	public static void main(String[] args) {

		// Cria��o de Objeto
		// [Classe Ref][id] = new [Classe Real];

		Pessoa pessoa = new Pessoa();

		pessoa.setNome("Carlos Roberto");
		pessoa.setEtnia("Branca");
		pessoa.setGenero('M');
		pessoa.setIdade(28);
		pessoa.setCpf(12312312345L);
		pessoa.setRg(123453453);
		pessoa.exibirDados();

		Pessoa pessoaDois = new Pessoa();

		pessoa.setNome("Sheize Maria");
		pessoa.setEtnia("Branca");
		pessoa.setGenero('F');
		pessoa.setIdade(40);
		pessoa.setCpf(11122233344L);
		pessoa.setRg(1231231231);
		pessoa.exibirDados();

		Pessoa pessoaTres = new Pessoa("Mario Joge", "Branca", 20, 'M', 12312312345L, 123456788);
		pessoaTres.exibirDados();
		
		Pessoa pessoaQuatro = new Pessoa("Maria Joaquina", 30);
		//pessoaQuatro.exibirDados();

		System.out.println("O nome � " + pessoaQuatro.getNome() + " e a idade " + pessoaQuatro.getIdade());
	}

}
