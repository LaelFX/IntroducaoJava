package com.senac.executaveis;

import java.util.Scanner;

import com.senac.classes.Pessoa;

public class ExecutavelDois {
	
	public static void main(String[] args) {
		
		Pessoa pessoa = new Pessoa();
		Scanner scan = new Scanner(System.in);
		String resposta = null;
		
		do{
			System.out.println("Digite o nome");
			pessoa.setNome(scan.nextLine());
		
			System.out.println("Digite a Etnia");
			pessoa.setEtnia(scan.nextLine());
			
			System.out.println("Digite o gen�ro");
			pessoa.setGenero((char) scan.nextLine().charAt(0));
			
			System.out.println("Digite a idade");
			pessoa.setIdade(scan.nextInt());
			
			System.out.println("Digite o CPF");
			pessoa.setCpf(scan.nextLong());
			
			System.out.println("Digite o RG");
			pessoa.setRg(scan.nextInt());
			
			pessoa.exibirDados();
			
			System.out.println("Deseja realizar outro cadastro?");
			scan.nextLine();
			resposta = scan.nextLine();
			
		}while(resposta.equals("s"));
		
		System.out.println("Obrigado por usar nosso sistema!");
			
	}

}
