package com.senac.interfaces;

public interface MatematicaInterfaceDiv {
	
	public double dividir(double x, double y);

}
