package com.senac.interfaces;

public interface MatematicaInterface {
	
	public int somar(int x, int y);
	
	public int subtrair(int x, int y);
	
	public void exibirMensagem(String msg);

}