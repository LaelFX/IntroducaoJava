package com.senac.interfaces;

public class MatematicaImpl implements MatematicaInterface, MatematicaInterfaceDiv {

	public int somar(int x, int y) {
		return x + y;
	}

	public int subtrair(int x, int y) {
		return x - y;
	}

	public void exibirMensagem(String msg) {
		System.out.println(msg);

	}

	public double dividir(double x, double y) {
		return x / y;
	}

}
