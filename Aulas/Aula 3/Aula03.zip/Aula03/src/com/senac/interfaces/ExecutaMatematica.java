package com.senac.interfaces;

import java.util.Scanner;

public class ExecutaMatematica {
	
	public static void main(String[] args) {
		
		Matematica matematics = new Matematica();
		MatematicaImpl matematicaImpl = new MatematicaImpl();
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Digite o valor de X");
		matematics.setX(scan.nextInt());
		
		System.out.println("Digite o valor de Y");
		matematics.setY(scan.nextInt());
		
		System.out.println(matematicaImpl.somar(matematics.getX(), matematics.getY()));
		System.out.println(matematicaImpl.subtrair(matematics.getX(), matematics.getY()));
		
		
		System.out.println("Digite o valor de x para divis�o");
		double x = scan.nextDouble();
		
		System.out.println("Digite o valor de y para divis�o");
		double y = scan.nextDouble();
		
		System.out.println(matematicaImpl.dividir(x, y));
		
		
		
		
	}

}
