package com.senac.heranca;

public class ExecutaHeranca {

	public static void main(String[] args) {
		
		Pai pai = new Pai();
		
		pai.setNome("Carlos");
		pai.setSobrenome("De Nobrega");
		pai.setCasa("Mans�o Alphaville");
		pai.exibirDados();

		Filho filho = new Filho();
		
		filho.setNome("Marcelo");
		filho.setSobrenome("de Nobrega");
		filho.setCasa("Mans�o Alphaville");
		filho.setEndereco("Rua das Acacias n� 48");
		filho.setTelefone("11945454545");
		filho.exibirDados();
		
		Primo primo = new Primo();
		primo.setBairro("Alphaville");
		primo.setCidade("S�o Paulo");
		
		System.out.println("O bairro � " + primo.getBairro() + " e a cidade � " + primo.getCidade());
		
		
	}

}
