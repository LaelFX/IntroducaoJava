package com.senac.heranca;

public class Filho extends Pai {

	private String endereco;
	private String telefone;

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	@Override
	public void exibirDados() {
		System.out.println("O nome � " + getNome() + " o sobrenome � " + getSobrenome() + " e a casa � " + getCasa()
				+ " e o endere�o � " + getEndereco() + " e o telefone � " + getTelefone());
	}

	@Override
	public void exibirDados(String nome, String sobrenome, String casa) {
		super.exibirDados(nome, sobrenome, casa);
	}
}
