package com.senac.heranca;

public class Pai {

	private String nome;
	private String sobrenome;
	private String casa;

	protected String getNome() {
		return nome;
	}

	protected void setNome(String nome) {
		this.nome = nome;
	}

	protected String getSobrenome() {
		return sobrenome;
	}

	protected void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}

	protected String getCasa() {
		return casa;
	}

	protected void setCasa(String casa) {
		this.casa = casa;
	}

	protected void exibirDados() {
		System.out.println("O nome � " + getNome() + " o sobrenome � " + getSobrenome() + " e a casa � " + getCasa());
	}
	
	protected void exibirDados(String nome, String sobrenome, String casa) {
		System.out.println("O nome � " + nome + " o sobrenome � " + sobrenome + " e a casa � " + casa);
	}

}
