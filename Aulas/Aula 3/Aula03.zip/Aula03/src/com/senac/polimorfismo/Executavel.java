package com.senac.polimorfismo;

public class Executavel {

	public static void main(String[] args) {

		Carro car = new Carro();

		car.setMarca("Ford");
		car.setCor("Preto");
		car.setModelo("Edge");
		
		Agencia ag = new Agencia();

		ag.setMarca("Chevrolet");
		ag.setCor("Prata");
		ag.setModelo("Onix LTZ");

		System.out.println("A marca " + car.getMarca() + " a cor " + car.getCor() + " e o modelo � " + car.getModelo());

		System.out.println("A marca " + ag.getMarca() + " a cor " + ag.getCor() + " e o modelo � " + ag.getModelo());

	}

}
