package com.senac.sobrecarga;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class TratamentoString {

	
	public static void main(String[] args) {
		
		DecimalFormat format = new DecimalFormat("#.##");
		NumberFormat pol = NumberFormat.getInstance();
		double valor = 1.7;
		
		String x = format.format(valor);
		
		
		System.out.println(x);
		
	}
}
