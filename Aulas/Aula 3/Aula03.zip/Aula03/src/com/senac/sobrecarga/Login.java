package com.senac.sobrecarga;

public class Login {

	private String login;
	private String senha;

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public void validaLogin() {
		setLogin("lael");
		setSenha("1235");

		if (getLogin().equals("lael") && getSenha().equals("123")) {
			System.out.println("Usu�rio permitido!");
		} else {
			System.out.println("Login ou senha inv�lidos!");
		}
	}

	public void validaLogin(String login, String senha) {
		if (getLogin().equals("lael") && getSenha().equals("123")) {
			System.out.println("Usu�rio permitido!");
		} else {
			System.out.println("Login ou senha inv�lidos!");
		}
	}

}
