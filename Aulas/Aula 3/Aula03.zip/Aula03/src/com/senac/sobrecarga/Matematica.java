package com.senac.sobrecarga;

// Sobrecarga
public class Matematica {

	public void mostrarTexto(String msg) {
		System.out.println(msg);
	}

	public void mostrarTexto() {
		System.out.println("Mostrando Texto agora!");
	}

	public int somar(int x, int y) {
		return x + y;
	}

	public int somar(int x, int y, int w) {
		return x + y + w;
	}

	public double somar(double x, double y) {
		return x + y;
	}

	public double dividir(int x, int y) {
		return x / y;
	}

	public double dividir(int x, int y, int w) {
		return (x / y) * w;
	}

}
