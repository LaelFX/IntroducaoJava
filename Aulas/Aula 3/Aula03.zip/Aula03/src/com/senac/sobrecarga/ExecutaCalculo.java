package com.senac.sobrecarga;

public class ExecutaCalculo {

	public static void main(String[] args) {

		// Sobre carga classe matematica

		Matematica matematics = new Matematica();

		System.out.println(matematics.somar(5, 5));
		System.out.println(matematics.somar(5, 5, 5));
		System.out.println(matematics.somar(1.5, 1.5));

		System.out.println(matematics.dividir(10, 2));
		System.out.println(matematics.dividir(10, 2, 2));

		matematics.mostrarTexto();
		matematics.mostrarTexto("Aula de POO");

		// Exemplo de sobrecarga login

		Login login = new Login();
		login.validaLogin();

		login.setLogin("lael");
		login.setSenha("123");
		login.validaLogin(login.getLogin(), login.getSenha());

	}

}
