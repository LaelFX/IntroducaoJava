package com.senac.classes;

//Classe Modelo
public class Pessoa {

	// [Visibilidade][tipo de dados][id]

	private String nome;
	private String etnia;
	private int idade;
	private char genero;
	private long cpf;
	private int rg;

	// Construtores
	public Pessoa() {}
	
	public Pessoa(String nome, String etnia, int idade, char genero, long cpf, int rg){
		this.nome = nome;
		this.etnia = etnia;
		this.idade = idade;
		this.genero = genero;
		this.cpf = cpf;
		this.rg = rg;
	}
	
	public Pessoa(String nome, int idade){
		this.nome = nome;
		this.idade = idade;
	}

	// Set -> Passagem de valor
	public void setNome(String nome) {
		this.nome = nome;
	}

	// Get -> Busca valor passado
	public String getNome() {
		return nome;
	}

	public String getEtnia() {
		return etnia;
	}

	public void setEtnia(String etnia) {
		this.etnia = etnia;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public char getGenero() {
		return genero;
	}

	public void setGenero(char genero) {
		this.genero = genero;
	}

	public long getCpf() {
		return cpf;
	}

	public void setCpf(long cpf) {
		this.cpf = cpf;
	}

	public int getRg() {
		return rg;
	}

	public void setRg(int rg) {
		this.rg = rg;
	}

	public void exibirDados() {
		System.out.println("O nome " + getNome() + " a etnia � " + getEtnia() + " o gen�ro � " + getGenero()
				+ " a idade � " + getIdade() + " o CPF � " + getCpf() + " e o RG � " + getRg());
	}

}
