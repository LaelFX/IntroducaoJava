package br.com.senac.palavras; 

public class PessoaModelo extends ClasseModelo{
	
	
	@Override
	public void setNome(String nome) {
		super.setNome(nome);
	}
	
	
	@Override
	public void setIdade(int idade) {
		super.setIdade(idade);
	}

	@Override
	public void exibirDados() {
		System.out.println(getNome() + " " + getIdade());
	}

}
