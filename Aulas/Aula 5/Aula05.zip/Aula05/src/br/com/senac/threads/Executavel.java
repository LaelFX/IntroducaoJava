package br.com.senac.threads;

import java.util.Scanner;

public class Executavel {

	public static void main(String[] args) throws InterruptedException {

		int contadora = 1;
		int tabuada = 2;

		Scanner scan = new Scanner(System.in);
		ThreadModel thr = new ThreadModel();

		while (contadora <= 10) {
			System.out.println(tabuada + " X " + contadora + " = " + (2 * contadora));
			contadora++;
		}

		thr.start();
		System.out.println("Deseja para a Thread");

		if (scan.next().equals("s")) {
			System.out.println("Thread parada!");
			thr.sleep(1000);
		}

	}

}
