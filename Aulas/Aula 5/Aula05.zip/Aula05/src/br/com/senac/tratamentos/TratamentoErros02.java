package br.com.senac.tratamentos;

public class TratamentoErros02 {

	public static void main(String[] args) {

		// texto("Aula de Java");
		texto("1000");
		// textoDois("Aula de Java");

	}

	public static void texto(String msg) {

		try {
			// System.out.println(msg);
			System.out.println(Integer.parseInt(msg));
		} catch (NumberFormatException e) {
			// Lan�ar novas exce��es
			// throw new RuntimeException(); Exce��o de time e execu��o
			// System.out.println(new IOException().getMessage());
			System.out.println(e);
			System.out.println("O erro � -> " + e.getMessage());
		}

	}

	public static void textoDois(String msg) throws Exception {
		System.out.println(msg);
		System.out.println(Integer.parseInt(msg));
	}

}
