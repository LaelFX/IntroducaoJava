package br.com.senac.datas;

import java.time.LocalDate;
import java.time.Period;

public class CalculoDatas {

	public static void main(String[] args) {

		LocalDate dataNascimento = LocalDate.of(1960, 05, 22);
		System.out.println(Period.between(dataNascimento, LocalDate.now()).getYears());
	}

}
