package br.com.senac.threads;

public class ThreadRun02 {

	public static void main(String[] args) throws InterruptedException {

		ThreadRun thrRun = new ThreadRun();
		ThreadModelDois thModel = new ThreadModelDois();

		Thread th = new Thread(thrRun);
		Thread th2 = new Thread(thrRun);
		Thread th3 = new Thread(thModel);

		System.out.println("Abaixo o ano do mundial do Palmeiras...");

		th.start();

		if (th.getState().toString().equals("RUNNABLE")) {
			System.exit(0);
		}

		// if (th.isAlive()) {
		// System.exit(0);
		// }

		th3.sleep(3000);
		th3.start();
		// th2.sleep(5000);
		// th2.start();
	}

}
