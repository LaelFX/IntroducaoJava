package br.com.senac.datas;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class GestaoDataTempo {
	
	public static void main(String[] args) {
		
		LocalDateTime  ldt = LocalDateTime.now();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yy HH:mm:ss");
		System.out.println(ldt); // Uso normal para Timestamp
		System.out.println(dtf.format(ldt));
		
		// System.out.println(ldt.getDayOfWeek());
		// System.out.println(ldt.getDayOfYear());
		// System.out.println(ldt.getChronology());
		// System.out.println(ldt.getMonth());
		// System.out.println(ldt.getDayOfMonth());
		// System.out.println(ldt.getMonthValue());
		
		
		
		
		
	}

}
