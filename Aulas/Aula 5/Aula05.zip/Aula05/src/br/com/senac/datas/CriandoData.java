package br.com.senac.datas;

import java.time.LocalDate;

public class CriandoData {

	public static void main(String[] args) {

		LocalDate data = LocalDate.now();
		System.out.println(data);

		System.out.println(data.getDayOfWeek());
		System.out.println(data.getDayOfMonth());
		System.out.println(data.getMonth());
		System.out.println(data.getMonthValue());
		System.out.println(data.getYear());

		System.out.println(data.getDayOfMonth() + "/" + data.getMonthValue() + "/" + data.getYear());
		
		System.out.println(data.lengthOfYear());
	}

}
