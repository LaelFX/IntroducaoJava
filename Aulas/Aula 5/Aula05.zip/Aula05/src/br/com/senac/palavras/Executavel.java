package br.com.senac.palavras;

public class Executavel {

	public static void main(String[] args) {

		// ClasseModelo clm = new ClasseModelo(); Classe abstrata n�o pode ser
		// construida
		PessoaModelo pesm = new PessoaModelo();

		pesm.setNome("Carlos");
		pesm.setIdade(90);
		pesm.exibirDados();

		ClasseFinal cf = new ClasseFinal(); // Uma classe com final s� pode ser
											// inst�ncia

		cf.setTexto("Testando o m�todo");
		// System.out.println(cf.getTexto());

		// ClasseFinal.exibirTexto("Texto Aleat�rio");
		ClasseFinal.exibirTexto(cf.getTexto()); // M�todo acessado estaticamente

	}

}
