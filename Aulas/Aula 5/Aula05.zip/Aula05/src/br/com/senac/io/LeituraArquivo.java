package br.com.senac.io;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class LeituraArquivo {

	public static void main(String[] args) throws IOException {

		Scanner scan = new Scanner(System.in);
		System.out.println("Digite o nome do arquivo para leitura");
		File file = new File(
				"C:\\Users\\a1937563\\OneDrive - C&A Modas Ltda\\�rea de Trabalho\\" + scan.nextLine() + ".txt");

		if (!file.exists()) {
			System.out.println("Arquivo n�o encontrado!");
		} else {
			lerArquivo(file);
		}

	}

	public static void lerArquivo(File file) throws IOException {

		Scanner scan = new Scanner(new FileReader(file));
		System.out.println("-----------------------------------");
		while (scan.hasNextLine()) {
			System.out.println(scan.nextLine());
		}

	}

}
