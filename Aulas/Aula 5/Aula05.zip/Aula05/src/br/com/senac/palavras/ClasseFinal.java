package br.com.senac.palavras;

public final class ClasseFinal {
	
	// A Classe precisa ser Inst�ncia
	// N�o se pode criar extens�o

	private String texto;

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public static void exibirTexto(String texto){
		System.out.println("O texto digitado � " + texto);
	}

}
