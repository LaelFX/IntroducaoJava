package br.com.senac.io;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class EscritaArquivo {

	public static void main(String[] args) throws IOException {

		Scanner scan = new Scanner(System.in);
		System.out.println("Digite o novo arquivo!");
		File arquivo = new File("C:\\Users\\a1937563\\OneDrive - C&A Modas Ltda\\�rea de Trabalho\\"+ scan.next() + ".txt");

		while (arquivo.exists()) {
			System.out.println("Arquivo de Aula Existente!");
			System.out.println("Digite o novo arquivo!");
			arquivo = new File("C:\\Users\\a1937563\\OneDrive - C&A Modas Ltda\\�rea de Trabalho\\"+ scan.next() + ".txt");

		}
		
		escreveArquivo(arquivo);
	}

	public static void escreveArquivo(File arquivo) throws IOException {

		FileWriter escrever = new FileWriter(arquivo); // True permite gravar nova linha / False Sobreescreve arquivo
		Scanner scan = new Scanner(System.in);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yy HH:mm");
		String resposta = "";

		if (!arquivo.exists()) {
			arquivo.createNewFile();
			System.out.println("Arquivo criado!");
		}
		escrever.write(dtf.format(LocalDateTime.now()).toString()+"\n");
		do {
			System.out.println("Digite um texto");

			escrever.write(scan.nextLine()+"\n");
			escrever.flush();

			System.out.println("Deseja escrever mais alguma coisa??");
			resposta = scan.nextLine();

		} while (resposta.equals("s"));
		
		escrever.close();

		System.out.println("Voc� parou de escrever!");

	}

}
