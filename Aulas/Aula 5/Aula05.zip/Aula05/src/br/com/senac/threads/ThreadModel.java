package br.com.senac.threads;

public class ThreadModel extends Thread {

	@Override
	public void run() {
		System.out.println("O Palmeiras n�o tem mundial!!!");
	}
}
