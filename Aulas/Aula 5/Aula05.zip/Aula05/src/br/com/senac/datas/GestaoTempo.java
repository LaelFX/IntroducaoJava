package br.com.senac.datas;

import java.time.LocalTime;

public class GestaoTempo {
	
	public static void main(String[] args) {
		
		LocalTime tempo = LocalTime.now();
		
		System.out.println(tempo);
		System.out.println(tempo.getHour());
		System.out.println(tempo.getMinute());
		System.out.println(tempo.getSecond());
		System.out.println(tempo.getNano());
		System.out.println(tempo.toNanoOfDay());
		System.out.println(tempo.withHour(13));
		System.out.println(tempo.withMinute(25));
		System.out.println(tempo.with(LocalTime.of(13,45,00)));
		
	}

}
