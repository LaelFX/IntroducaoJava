package br.com.senac.palavras;

public abstract class ClasseModelo {
	// Uma classe abstrata ele n�o pode ser inst�ncia
	// Uma classe abstrata s� pode ser extendida
	
	private String nome;
	private int idade;
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	public abstract void exibirDados();
}
