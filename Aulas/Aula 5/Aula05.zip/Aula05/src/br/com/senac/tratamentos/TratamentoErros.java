package br.com.senac.tratamentos;

public class TratamentoErros {

	public static void main(String[] args) {

		// try{ Tentar algo }catch(Exception e){ Tratamento }finally{ Finalizar
		// }

		String texto = "";
		int convert = 0;
		double convertTwo = 0;

		try {

			texto = "O Palmeiras n�o tem mundial!";
			// texto = "0";
			// convert = Integer.parseInt(texto);
			convertTwo = Double.parseDouble(texto);
			System.out.println(texto);

		} catch (Exception e) {
			System.out.println(e);
			System.out.println(e.getMessage());
			System.out.println("Erro na parte try!");
		} finally {
			System.out.println("Finalizando o tratamento!");
		}

	}

}
