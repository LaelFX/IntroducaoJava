package br.com.senac.libs;

import br.com.matematica.methods.impl.MethodsServiceImpl;

public class Calculando {

	public static void main(String[] args) {

		MethodsServiceImpl calc = new MethodsServiceImpl();

		System.out.println(calc.somar(5, 5));
		System.out.println(calc.somar(5.5, 5.5));

		System.out.println(calc.subtrair(2, 1));
		System.out.println(calc.subtrair(5.5, 2.1));

		System.out.println(calc.multiplicar(2, 4));
		System.out.println(calc.multiplicar(5.5, 2));

		System.out.println(calc.dividir(30, 2));

	}

}
