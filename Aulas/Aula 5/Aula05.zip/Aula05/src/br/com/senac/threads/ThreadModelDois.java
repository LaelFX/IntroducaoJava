package br.com.senac.threads;

public class ThreadModelDois implements Runnable{

	@Override
	public void run() {
		System.out.println("Executando verdades nas Threads!");		
	}
}
