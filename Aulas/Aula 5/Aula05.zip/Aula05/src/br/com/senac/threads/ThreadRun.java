package br.com.senac.threads;

public class ThreadRun implements Runnable {

	@Override
	public void run() {
		
//		System.out.println("MUNDIAL!!!");
//		int contadora = 0;
//		while (contadora <= 10) {
//			System.out.println(contadora);
//			contadora++;
//		}
		
		while(true){
			System.out.println("Erro");
		}
	}
}
