package com.senac.matematics;

public class Aritmeticos {

	public static void main(String[] args) {

		// -- Operadores Artim�ticos
		// + -> Somar
		// - -> Substra��o
		// * -> Multiplica��o
		// / -> Divis�o

		int x = 5; // 1,5 -> 1
		int y = 10;
		int a = 15;
		int b = 15;

		double w = 5; // 0,0

		// Adi��o
		System.out.println(x + y);
		System.out.println(a + b);
		System.out.println(x + y + 20);

		// Subtra��o
		System.out.println(a - b);
		System.out.println(a - b + 2);

		// Multiplica��o
		System.out.println(x * y);

		// Concatena��o
		System.out.println("O resultado da soma de " + a + " + " + b + " � " + (a + b));

		// Divis�o
		System.out.println(a / w);
		System.out.println((a / w) / 2);

	}

}
