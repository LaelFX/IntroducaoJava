package com.senac.constantes;

public class Constantes {

	public static void main(String[] args) {

		// -- Exemplo de VAR
//		 int idade = 25;
//		 System.out.println(idade);
//		
//		 idade = 40;
//		 System.out.println(idade);
//		
//		 idade = 2;
//		 System.out.println(idade);

		final int idade = 25;
		System.out.println(idade);
		
//		 idade = 30;
//		 System.out.println(30);
	
	}

}
