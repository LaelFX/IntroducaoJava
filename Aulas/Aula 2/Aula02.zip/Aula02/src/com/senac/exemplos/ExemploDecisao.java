package com.senac.exemplos;

import java.util.Scanner;

public class ExemploDecisao {

	public static void main(String[] args) {

		// Importando o Scanner para leitura do valor do input
		Scanner scan = new Scanner(System.in);

		int option = 0;

		System.out.println("Escolha uma forma de pagamento");
		System.out.println("1 - Cr�dito\n2 - D�bito\n3 - Pix");
		option = scan.nextInt();

		// System.out.println(option);
		
		if(option == 1)
			System.out.println("Pagamento efetuado em cr�dito!");
		else if(option == 2)
			System.out.println("Pagamento efetuado em d�bito!");
		else if(option == 3)
			System.out.println("Pagamento via PIX!");
		else
			System.out.println("Forma de pagamento n�o aceita!");
	}

}
