package com.senac.exemplos;

import java.util.Scanner;

public class ExemploCaso {

	public static void main(String[] args) {

		System.out.println("----- Bem Vindo ao ATM -----");
		System.out.println("Escolha seu banco \n1- Caixa\n2- Santander");
		int option = new Scanner(System.in).nextInt();

		switch (option) {
		case 1:
			System.out.println("Bem vindo a Caixa");
			break;
		case 2:
			System.out.println("Bem vindo ao Santander");
			break;
		default:
			System.out.println("Banco n�o reconhecido!");
			System.out.println("Obrigado por utilizar nossos servi�os");
			System.exit(0);
			break;
		}

		System.out.println("Escolha o que deseja fazer\n1-Saque\n2-Pagamento");
		int acao = new Scanner(System.in).nextInt();

		switch (acao) {
		case 1:
			System.out.println("Voc� efetuou um saque!");
			break;
		case 2:
			System.out.println("Voc� efetuou pagamento!");
			break;
		default:
			System.out.println("Op��o Inv�lida!");
			break;
		}

		System.out.println("Obrigado por utilizar nossos servi�os");

		// Escolha(variavel/valor){
		// caso seja "Valor"
		// Resposta
		// caso seja "ValorDOis"
		// Resposta2
		// }

	}

}
