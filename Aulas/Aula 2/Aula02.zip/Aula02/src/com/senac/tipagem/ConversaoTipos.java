package com.senac.tipagem;

public class ConversaoTipos {

	public static void main(String[] args) {
	
		// Convers�es de Tipos - CAST / CASTING
		
		String valor = "1";		
		final int valorDois = 2;
		
		//Convertendo a var valor em inteiro
		int novoValor = Integer.parseInt(valor);
		
		//Exibindo um calculo do valor convertido + valorDois do tipo inteiro
		System.out.println(valorDois + novoValor);
		
		//Convertendo o valorDois numerico em texto
		String valorDoisTexto = String.valueOf(valorDois);
	
		//Exibindo a concatena��o dos valores em texto
		System.out.println(valorDoisTexto + " " +valor);	
		
		//Exibindo o calculo da vari�vel inteira + 2
		System.out.println(valorDois + 2);
		
		/*Exibindo o calculo da vari�vel de texto + 2 que n�o pode ser calculada
		 * e vira uma concatena��o
		 */
		System.out.println(valorDoisTexto + 2);
		

	}

}
