package com.senac.lacos;

public class LacoFacaEnquanto {

	public static void main(String[] args) {

		int contadora = 1;

		do {

			System.out.println(contadora);
			contadora++;

		} while (contadora <= 10);

		// FACA ENQUANTO
		// Ele vai executar pelo menos uma vez o c�digo ate verificar se �
		// verdadeiro

	}

}
