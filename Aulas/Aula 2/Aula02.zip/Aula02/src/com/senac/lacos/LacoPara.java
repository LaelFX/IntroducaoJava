package com.senac.lacos;

public class LacoPara {

	public static void main(String[] args) {

		for (int contadora = 1; contadora <= 10; contadora++) {
			System.out.println(contadora);
		}

		System.out.println();
		System.out.println(" PARES ");
		System.out.println();

		// Imprime n�mero PAR
		for (int contadora = 2; contadora <= 10; contadora += 2) {
			System.out.println(contadora);
		}

		System.out.println();
		System.out.println(" IMPARES ");
		System.out.println();

		// Imprimi n�mero IMPAR
		for (int contadora = 1; contadora <= 10; contadora += 2) {
			System.out.println(contadora);
		}

		//Incremento/Decremento
		// COMUNS ++ / --
		// COMUNS += / -=
		
		// System.out.println();
		// System.out.println("DECREMENTO");
		// System.out.println();
		//
		// for(int contadora = 10; contadora >= 0; contadora--){
		// System.out.println(contadora);
		// }

		// for(Inicio; Fim; Incremento/Decremento){
		// C�digo
		// }

	}

}
