package com.senac.lacos;

public class LacoEnquanto {

	public static void main(String[] args) throws InterruptedException {

		int contador = 0;

//		while(contador <= 10){
//			System.out.println(contador);
//			Thread.sleep(2000);
//			contador = contador + 1;
//		}
			
			while(contador <= 10){
				System.out.println(contador);
				contador ++;
			}
			
			System.out.println();
			System.out.println("EXECUTANDO DECREMENTO");
			System.out.println();
			
			contador = 10;
			
			while(contador >= 0){
				System.out.println(contador);
				contador--;
			}	
		
		
		// LOOPING
		// LOOPING INFINITO -> Acontece quando n�o se d� o incremento do elemento contador
		// EXECUTA APENAS ENQUANTO FOR VERDADEIRO
		// ENQUANTO (Condi��o) ENTAO
		// CODIGO REPETIDO
		// FIMENQUANTO
	}

}
