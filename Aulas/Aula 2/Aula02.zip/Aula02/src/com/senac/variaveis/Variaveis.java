package com.senac.variaveis;

public class Variaveis {

	public static void main(String[] args) {
		
		// [Tipo de dados] [ID]
		
		String nome = "Carlos Alberto"; 
		int idade = 20;
		char genero = 'M';
		
//		System.out.print(nome);
//		System.out.print(idade);
//		System.out.print(genero);
		
		System.out.println("O nome � "+nome+" a idade � "+idade+" e o gen�ro � "+genero);
		
	}
}
