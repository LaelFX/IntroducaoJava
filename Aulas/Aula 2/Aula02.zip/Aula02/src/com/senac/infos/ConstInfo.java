package com.senac.infos;

public class ConstInfo {
	
	/* Constante s�o blocos l�gicos que permitem armazenar valores com base no tipo
	 * Constante armazenam um valor �nico que n�o pode ser substitu�do
	 * Tipagem de Dados
	  
	 --Primitivos
	 
	 * String = Cadeia de caracteres |Caracteres ou Textos
	 * char = texto caractere �nico  |
	 
	 * int    | N�mericos Inteiros
	 * long	  |
	 * byte   |
	 * short  |
	 
	 * float  |N�mericos Reais 0,0
	 * double |
	 
	 *boolean | Condi��o Verdadeiro ou Falso -> TRUE / FALSE
	 
	 *Object  | N�o possuem tipo espec�fico
	 
	 -- N�o Primitivos
	 
	 *Date     | Da lib do Java trabalha com Datas
	 *Calendar |
	 
	 */

}
