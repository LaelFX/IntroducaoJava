package com.senac.infos;

public class LacosInfo {

	// --Tipos de La�os

	// While - Enquanto
	// Do While - Fa�a Enquanto
	// For - Para

	// La�o -> estrutura de repeti��o
	// Permitir que voc� execute repeti�oes de um determinado contexto
}
