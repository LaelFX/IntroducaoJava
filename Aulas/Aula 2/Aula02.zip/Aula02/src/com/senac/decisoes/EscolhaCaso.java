package com.senac.decisoes;

public class EscolhaCaso {

	public static void main(String[] args) {

		// cc - Cart�o Cr�dito / cd - Cart�o de D�bito / dd - Dinheiro / px - PIX

		String formaPagamento = "cc";

		switch (formaPagamento) {

		case "cc":
			System.out.println("Pagamento com Cart�o de Cr�dito");
			break;
		case "cd":
			System.out.println("Pagamento com Cart�o de D�bito");
			break;
		case "dd":
			System.out.println("Pagamento com Dinheiro");
			break;
		case "px":
			System.out.println("Pagamento em PIX");
			break;
		default:
			System.out.println("Tipo de Pagamento n�o aceito!");
			break;
		}

	}

}
