package com.senac.decisoes;

public class EstruturaDecisao {

	public static void main(String[] args) {

		// OPERADORES RELACIONAIS
		// > MAIOR
		// < MENOR
		// >= MAIOR OU IGUAL
		// <= MENOR OU IGUAL
		// != DIFERENTE ( <> )
		// == IGUAL

		// -- ESTRUTURA DE PERGUNTA E RESPOSTA
		// SE SENAO - IF

		// SE (CONDI��O) ENTAO
		// FA�A ISSO - VERDADEIRO
		// SENAO
		// FA�A AQUILO - FALSO
		// FIMSE

		// IF => se / ELSE => SENAO

		int x = 10;

		if (x > 10) {
			System.out.println("� Maior que 10!");
		} else {
			System.out.println("� Menor que 10!");
		}

		x = 10;

		if (x >= 10) {
			System.out.println("� maior ou igual a 10!");
		} else {
			System.out.println("� menor que 10!");
		}

		x = 11;

		if (x > 10) {
			System.out.println("� maior que 10!");
		}

		x = 20;

		if (x > 20) {
			System.out.println("Vari�vel X � maior que 20!");
		} else if (x < 20) {
			System.out.println("Vari�vel x � menor que 20!");
		} else {
			System.out.println("Vari�vel x � igual a 20!");
		}

	}

}
