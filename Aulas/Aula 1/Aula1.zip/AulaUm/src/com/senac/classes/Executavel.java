package com.senac.classes;

public class Executavel {
	
	public static void main(String [] args) {
		
		System.out.print("Hello World!");
		
	}
}
