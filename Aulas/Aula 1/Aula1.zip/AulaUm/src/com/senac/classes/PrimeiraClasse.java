package com.senac.classes;

public class PrimeiraClasse {
	
//	EXECUTAR O QUE EST� DENTRO DA CHAVE

//	Dois Tipos de classe
//	Modelo -> Base de um objeto que ser� utilizada
//	Execut�vel -> Executa as tarefas inseridas na estrutura
	
}
