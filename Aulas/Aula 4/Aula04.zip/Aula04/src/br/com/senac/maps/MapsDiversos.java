package br.com.senac.maps;

import java.util.HashMap;
import java.util.Map;

public class MapsDiversos {

	public static void main(String[] args) {

		Map<Integer, Integer> numeros = new HashMap<>();
		Map<Object, Object> objeto = new HashMap<>();

		numeros.put(1, 20);
		numeros.put(2, 100);

		// numeros.entrySet().forEach(x -> {
		// System.out.println("Key => " + x.getKey() + " Value => " +
		// x.getValue());
		// });

		objeto.put(1, 2);
		objeto.put("Carlos", "Alberto");
		Object[] vetor = new Object[2];

		objeto.entrySet().forEach(x -> {
			System.out.println(x.getKey());
		});

		// Abstraindo as keys n�mericas do map
		// Object number = objeto.get(1);
		// Object numberDois = objeto.get(1);

		numeros.entrySet().forEach(x -> {
			for (int i = 1; i < vetor.length; i++) {
				vetor[i] = x.getKey();
			}
		});

		// System.out.println("VETOR");
		// for(int i=1; i < vetor.length; i++){
		// System.out.println(vetor[i]);
		// }

		// System.out.println(vetor[1]);
		int x = Integer.parseInt(objeto.get(1).toString());
		int y = Integer.parseInt(objeto.get(1).toString());

		// System.out.println((x + y));

	}

}
