package br.com.senac.strings;

public class CharPointAtMetodo {

	public static void main(String[] args) {

		String texto = "Aula de Java";

		// CodePointAt
		// Receber um valor de char e mostrar o UNICODE do teclado

		System.out.println(texto.codePointAt(0));
		System.out.println(texto.codePointAt(8));
		
		// 65 => A - 74 => J

	}

}
