package br.com.senac.arrays;

public class VetoresInicializados {

	public static void main(String[] args) {

		String[] nomes = { "Carlos", "Sheila", "Roberto" };
		//                    [0]       [1]       [3]

		// System.out.println("O 1� nome � " + nomes[0]);
		// System.out.println("O 2� nome � " + nomes[1]);
		// System.out.println("O 3� nome � " + nomes[2]);

		for (int i = 0; i < nomes.length; i++) {
			System.out.println("O " + (i + 1) + "� nome � " + nomes[i]);
		}
	}

}
