package br.com.senac.strings;

public class StringBuilderMetodo {

	public static void main(String[] args) {

		// StringBuilder
		// Utiizado para a composi��o de longas escritas como Query de JDBC
		
		StringBuilder sb = new StringBuilder();

		sb.append("Aula");
		sb.append(" ");
		sb.append("de");
		sb.append(" ");
		sb.append("Java");

		System.out.println(sb);

	}

}
