package br.com.senac.maps;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UsandoMaps {

	public static void main(String[] args) {

		// Arraylist<Tipo �nico>
		// Map<String, Integer>
		// [key], [valor]

		Scanner scan = new Scanner(System.in);
		Map<String, String> nomes = new HashMap<String, String>();

		nomes.put("n1", "Carlos");
		nomes.put("n2", "Sheila");
		nomes.put("n3", "Roberto");
		nomes.put("n4", "Marcos");

		// nomes.entrySet().forEach(x -> {
		// System.out.println("---------------------");
		// System.out.println("Valor do map " + x);
		// System.out.println("Valor da key " + x.getKey());
		// System.out.println("Valor real " + x.getValue());
		// System.out.println("---------------------");
		// });
		
		System.out.println("Digite a chave que quer buscar");
		buscarDado(nomes, scan.nextLine());
		
	}

	public static void buscarDado(Map<String, String> map, String key) {

		if (map.containsKey(key)) {
			System.out.println("A chave � "+ key +" e o valor da chave � "+ map.get(key));
		} else {
			System.out.println("Valor da chave n�o encontrada!");
		}

	}

}
