package br.com.senac.arrays;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class VetoresDinamicos02 {

	public static void main(String[] args) {

		List<String> listaNomes = new ArrayList<String>();
		// List<Integer> numeros = new ArrayList<Integer>();
		// List<Object> objeto = new ArrayList<Object>();
		
		// ArrayList<String> listaNomes = new ArrayList<String>(); Jeito menos comum
		Scanner scan = new Scanner(System.in);
		String resposta = "";

		do {

			System.out.println("Digite os nomes");
			listaNomes.add(scan.nextLine());

			System.out.println("Deseja implementar mais nomes?");
			resposta = scan.nextLine();

		} while (resposta.equals("s"));

		// Foreach
		for (String nomes : listaNomes) {
			System.out.println("O nome � " + nomes);
		}

		System.out.println("");
		System.out.println("---- LAMBDAS ----");

		// Lambda Java 8
		listaNomes.forEach(x -> {
			System.out.println(x);
		});

		System.out.println("O tamanho atual do array � " + listaNomes.size());
		
	}

}
