package br.com.senac.strings;

public class VetoresChar {

	public static void main(String[] args) {
		
		// ToCharArray
		// Converte um String em um array de char
		
		String texto = "Aula de Java";
		char [] textoArray = texto.toCharArray();
		
		for(char vetorChar : textoArray){
			System.out.println(vetorChar);
		}
		System.out.println("---------------------------");
		System.out.println(textoArray[8]+""+textoArray[9]);
		
	}
	
}
