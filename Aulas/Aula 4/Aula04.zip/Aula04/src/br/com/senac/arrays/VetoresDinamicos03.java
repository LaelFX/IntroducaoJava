package br.com.senac.arrays;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import br.com.senac.model.Pessoa;

public class VetoresDinamicos03 {

	public static void main(String[] args) {

		List<Pessoa> pessoaList = new ArrayList<>();
		Scanner scan = new Scanner(System.in);
		String resposta = "";

		System.out.println("-- AGENDA --");
		
		do {
			
			Pessoa pessoa = new Pessoa();
			
			System.out.println("-- CADASTRO DE PESSOAS --");
			
			System.out.println("Digite o nome");
			pessoa.setNome(scan.nextLine());
			
			System.out.println("Digite a idade");
			pessoa.setIdade(scan.nextInt());
			
			pessoaList.add(pessoa);			
			
			scan.nextLine();
			System.out.println("Deseja Inserir mais pessoas!");
			resposta = scan.nextLine();

		} while (resposta.equals("s"));
		
		pessoaList.forEach(x -> {
			System.out.println("O nome da pessoa � " + x.getNome()+ " e a idade � "+ x.getIdade());
		});
		
		System.out.println("");
		System.out.println("");
		pessoaList.forEach(x->{ System.out.println(x);});

	}

}
