package br.com.senac.strings;

public class ComparesToMetodo {
	
	public static void main(String[] args) {
		
		// ComparesTo e ComparesToIgnoreCase
		
		// Compara se determinada String � igual a outra
		// Ignore ignora caixa altas de baixas
		
		String texto = "Aula de Java";
		
		System.out.println(texto.compareTo("Aula de Python") == 0 ? true : false);
		System.out.println(texto.compareTo("Aula de Java") == 0 ? true : false);
		System.out.println(texto.compareTo("aula de java") == 0 ? true : false);
		
		// Ignorar caixa altas ou baixas
		System.out.println(texto.compareToIgnoreCase("aula de java") == 0 ? true : false);
		
	}

}
