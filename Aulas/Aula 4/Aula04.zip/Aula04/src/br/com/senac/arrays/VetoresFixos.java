package br.com.senac.arrays;

import java.util.Scanner;

public class VetoresFixos {

	public static void main(String[] args) {

		String[] nomes = new String[5];
		int[] numeros = new int[3];

		Scanner scan = new Scanner(System.in);

		System.out.println("1- Ver tamanho dos vetores\n2- Percorrer");
		int option = scan.nextInt();

		switch (option) {

		case 1:

			System.out.println("O tamanho do vetor nomes � " + nomes.length);
			System.out.println("O tamanho do vetor n�meros � " + numeros.length);
			break;

		case 2:
			scan.nextLine();

			for (int i = 0; i < nomes.length; i++) {
				System.out.println("Digite o nome");
				nomes[i] = scan.nextLine();
			}

			System.out.println("");
			System.out.println("--- LISTA DE NOMES ---");
			for (int i = 0; i < nomes.length; i++) {
				System.out.println("O " + (i + 1) + "� nome � " + nomes[i]);
			}

			for (int i = 0; i < numeros.length; i++) {
				System.out.println("Digite " + (i + 1) + "� n�mero");
				numeros[i] = scan.nextInt();
			}

			System.out.println("");
			System.out.println("--- LISTA DE N�MEROS ---");
			for (int i = 0; i < numeros.length; i++) {
				System.out.println("O " + (i + 1) + "� n�mero � " + numeros[i]);
			}
			break;
		default:
			System.out.println("Opera��o Inv�lida!");
			break;

		}
	}

}
