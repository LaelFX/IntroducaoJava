package br.com.senac.strings;

public class ComparaInicioFinal {

	public static void main(String[] args) {

		// EndsWith e StartsWith
		// Verifica se inico e fim termina com uma determinada palavra ou letra
		
		String texto = "Aula de Java";

		System.out.println(texto.endsWith("Python"));
		System.out.println(texto.endsWith("Java"));
		System.out.println("------------------------");
		System.out.println(texto.startsWith("Aula"));
		System.out.println(texto.startsWith("Java"));

	}

}
