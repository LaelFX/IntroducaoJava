package br.com.senac.strings;

public class SplitMetodo {
	
	public static void main(String[] args) {
		
		// Split
		// Recorta uma palavra e dividi em arrays com base no elemento(caracter) determinado
		
		String texto = "Aula de.Java";
//		String [] textoCortado = texto.split(" ");
		String [] textoCortado = texto.split("\\.");
		
		System.out.println(textoCortado[0]);
		System.out.println(textoCortado[1]);
//		System.out.println(textoCortado[2]);
		
		
	}

}
