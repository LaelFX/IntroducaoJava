package br.com.senac.maps;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Dados {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		Map<String, Integer> pessoa = new HashMap<>();
		String resposta = "";

		do {

			System.out.println("Digite o nome");
			String nome = scan.nextLine();

			System.out.println("Digite a idade");
			int idade = scan.nextInt();

			pessoa.put(nome, idade);

			scan.nextLine();
			System.out.println("Deseja registrar outra pessoa?");
			resposta = scan.nextLine();

		} while (resposta.equals("s"));

		pessoa.entrySet().forEach(x -> {
			System.out.println("O nome � " + x.getKey() + " e a idade � " + x.getValue());
		});

		// pessoa.forEach((x, y) -> {
		// System.out.printf("O nome � " + x + " e a idade � ", y +"\n");
		// });

	}

}
