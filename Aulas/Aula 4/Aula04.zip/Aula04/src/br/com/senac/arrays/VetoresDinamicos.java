package br.com.senac.arrays;

import java.util.ArrayList;
import java.util.Scanner;

public class VetoresDinamicos {

	public static void main(String[] args) {

		ArrayList<String> listaNomes = new ArrayList<String>();
		Scanner scan = new Scanner(System.in);
		String resposta = "";

		do {

			System.out.println("Digite os nomes");
			listaNomes.add(scan.nextLine());

			System.out.println("Deseja implementar mais nomes?");
			resposta = scan.nextLine();

		} while (resposta.equals("s"));

		for (int i = 0; i < listaNomes.size(); i++) {
			System.out.println(listaNomes.get(i));
		}

		// listaNomes.clear(); Limpar o array
		listaNomes.remove(1); // Remove dados por posi��o do array 

		System.out.println("");
		System.out.println("");
		System.out.println("--------------------------------");

		if (!listaNomes.isEmpty()) {
			for (int i = 0; i < listaNomes.size(); i++) {
				System.out.println(listaNomes.get(i));
			}
			System.out.println("O 2� nome � " + listaNomes.get(0));
		} else {
			System.out.println("ARRAY VAZIO!");
		}
	}

}
