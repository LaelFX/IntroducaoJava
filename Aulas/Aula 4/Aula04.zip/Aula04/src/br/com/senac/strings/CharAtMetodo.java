package br.com.senac.strings;

public class CharAtMetodo {
	
	public static void main(String[] args) {
		
		String texto = "Aula de Java";
		
		// CharAt
		// Resgata um �nico valor da String (posi��o)
		System.out.println(texto.charAt(3));
		
		System.out.println(texto.charAt(0) +""+ texto.charAt(1)+texto.charAt(2)+texto.charAt(3)+
		texto.charAt(4) + texto.charAt(5)+texto.charAt(6)+ texto.charAt(7)+ 
		texto.charAt(8)+texto.charAt(9)+ texto.charAt(10)+texto.charAt(11));
		
	}

}
