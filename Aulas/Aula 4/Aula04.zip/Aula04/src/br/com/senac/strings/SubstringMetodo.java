package br.com.senac.strings;

public class SubstringMetodo {

	public static void main(String[] args) {
		
		// Substring
		// Retorna posi��o e quantidade de caracteres especif�cas
		
		String texto = "Aula de Java";
		String numeroCartao = "32185825465465465";
		String numeroCartaoDois = "32185825465465465";
		
		System.out.println(texto.substring(1,6));
		System.out.println(texto.substring(1, 12));
		
		System.out.println(numeroCartao.substring(0,3));
		
		if(numeroCartao.substring(0,3).equals("147")){
			System.out.println("Bandeira Visa");
		}
		
		if(numeroCartaoDois.substring(0,3).equals("321") && numeroCartao.subSequence(0, 3).equals("321")){
			System.out.println("Bandeira Master");
		}
		
		
	}
	
}
