package br.com.senac.exercicios.ex03;

import java.util.Scanner;

public class FuncionamentoElevador {

	public static void main(String[] args) {

		Elevador elv = new Elevador();
		Scanner scan = new Scanner(System.in);
		String resposta = "";

		elv.inicializar(7, 6);

		do {

			System.out.println("1- Add pessoa \n2- Remover pessoa\n3- Sobe andar\n4- Desce andar");
			int option = scan.nextInt();

			switch (option) {

			case 1:
				elv.entrar();
				break;

			case 2:
				elv.sair();
				break;

			case 3:
				elv.sobe();
				break;

			case 4:
				elv.descer();
				break;

			default:
				System.out.println("Opera��o Inv�lida!");
			}

			System.out.println("O elevador est� funcionando??");
			resposta = scan.next();

			for (int i = 0; i <= 4; i++) {
				System.out.println("");
			}

		} while (resposta.equals("s"));
		
		System.out.println("Sistema Evelador Finalizado!");

	}

}
