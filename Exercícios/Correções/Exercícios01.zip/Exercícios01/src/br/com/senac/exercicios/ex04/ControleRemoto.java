package br.com.senac.exercicios.ex04;

public class ControleRemoto {

	private int volume;
	private int canal;

	public int getVolume() {
		return volume;
	}

	public void setVolume(int volume) {
		this.volume = volume;
	}

	public int getCanal() {
		return canal;
	}

	public void setCanal(int canal) {
		this.canal = canal;
	}

	public ControleRemoto() {
		setCanal(1);
	}

	public void aumentarSom() {
		if (getVolume() < 10) {
			setVolume(getVolume() + 1);
		} else {
			System.out.println("Volume m�ximo atingido!");
		}
	}

	public void mudarCanal() {
		if (getCanal() < 5) {
			setCanal(getCanal() + 1);
		} else {
			setCanal(1);
		}
	}

	public void canalIndicado(int canal) {
		if (canal > 0 && canal < 6) {
			setCanal(canal);
		} else {
			System.out.println("Canal n�o encontrado!");
			setCanal(1);
		}
	}

	public void info() {
		System.out.println("Canal " + getCanal() + " Volume " + getVolume());
	}

}
