package br.com.senac.exercicios.ex01;

import java.util.Scanner;

public class SetaDadosPessoa {
	
	public static void main(String[] args) {
		
		Pessoa pes = new Pessoa();
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Digite o nome da pessoa");
		pes.setNome(scan.nextLine());
		
		System.out.println("Digite a data de nascimento da pessoa");
		pes.setDataNascimento(scan.nextInt());
		
		System.out.println("Digite a altura da pessoa");
		pes.setAltura(scan.nextDouble());
		
		System.out.println("Digite o ano atual");
		int ano = scan.nextInt();
		
		pes.calcularIdade(ano);
		
		
	}

}
