package br.com.senac.exercicios.ex03;

public class Elevador {

	private int totalAndar;
	private int totalPessoas;
	private int andar;
	private int pessoas;

	public int getTotalAndar() {
		return totalAndar;
	}

	public void setTotalAndar(int totalAndar) {
		this.totalAndar = totalAndar;
	}

	public int getTotalPessoas() {
		return totalPessoas;
	}

	public void setTotalPessoas(int totalPessoas) {
		this.totalPessoas = totalPessoas;
	}

	public int getAndar() {
		return andar;
	}

	public void setAndar(int andar) {
		this.andar = andar;
	}

	public int getPessoas() {
		return pessoas;
	}

	public void setPessoas(int pessoas) {
		this.pessoas = pessoas;
	}

	public Elevador() {
	}

	public void inicializar(int totalAndar, int capacidadePessoas) {
		setTotalAndar(totalAndar);
		setTotalPessoas(capacidadePessoas);
		setAndar(0);
		setPessoas(0);
	}

	public void entrar() {
		if (getPessoas() < getTotalPessoas()) {
			setPessoas(getPessoas() + 1);
			System.out.println("H� " + getPessoas() + " pessoas no elevador!");
		} else {
			System.out.println("N�o h� mais espa�o no elevador!");
		}
	}

	public void sair() {
		if (getPessoas() > 0) {
			setPessoas(getPessoas() - 1);
			System.out.println("H� " + getPessoas() + " pessoas no elevador!");
		} else {
			System.out.println("N�o h� mais pessoas no elevador!");
		}
	}

	public void sobe() {
		if (getAndar() < getTotalAndar()) {
			setAndar(getAndar() + 1);
			System.out.println("Andar " + getAndar());
		} else {
			System.out.println("Voc� est� no �ltimo andar!");
		}
	}

	public void descer() {
		if (getAndar() > 0) {
			setAndar(getAndar() - 1);
			System.out.println("Andar " + getAndar());
		} else {
			System.out.println("Voc� j� est� no t�rreo!");
		}
	}

}
