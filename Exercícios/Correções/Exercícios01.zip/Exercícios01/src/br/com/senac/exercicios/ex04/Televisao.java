package br.com.senac.exercicios.ex04;

import java.util.Scanner;

public class Televisao {

	public static void main(String[] args) {

		ControleRemoto ctr = new ControleRemoto();
		Scanner scan = new Scanner(System.in);
		String resposta = "";

		do {
			System.out.println("1- + Volume\n2- + Canal\n3- Ale�torio\n4- Info TV");
			int option = scan.nextInt();

			switch (option) {

			case 1:
				ctr.aumentarSom();
				System.out.println("Volume " + ctr.getVolume());

				break;

			case 2:
				ctr.mudarCanal();
				System.out.println("Canal " + ctr.getCanal());

				break;
			case 3:
				System.out.println("Digite o n� do canal");
				int canal = scan.nextInt();

				ctr.canalIndicado(canal);
				System.out.println("Canal " + ctr.getCanal());

				break;
			case 4:
				ctr.info();

				break;

			default:
				System.out.println("Opera��o n�o encontrada!");
			}

			System.out.println("A TV est� ligada??");
			resposta = scan.next();

		} while (resposta.equals("s"));

		System.out.println("Voc� saiu do menu da TV!");
	}

}
